# Hades Discord connector

A surface pack for Hades. Install it with `hades pack add <this.tar.gz>` and run it with
`hades connector run discord --config <config>`. The token is read from
`HADES_CONNECTOR_DISCORD_TOKEN`; configure `gateway.connectors.discord` in the same config
file the daemon reads.
