# Hades Discord connector

A surface pack for Hades. Install it with `hades pack add <this.tar.gz>` and run it with
`hades connector run discord --config <config>`. The token is read from
`HADES_CONNECTOR_DISCORD_TOKEN`. The surface answers on the gateway's model and provider,
the same ones the rest of the install uses; `gateway.connectors.discord` only has to say
who may talk to it and where its channels are.
